"""
crawler.py — Discovers URLs and HTML forms on the target site.
Uses requests + BeautifulSoup with BFS up to a configurable depth.
"""

import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, urlencode
from collections import deque


class Crawler:
    def __init__(self, base_url: str, depth: int = 2, timeout: int = 10, headers: dict = None):
        self.base_url  = base_url.rstrip("/")
        self.depth     = depth
        self.timeout   = timeout
        self.visited   = set()
        self.found_urls  = []
        self.found_forms = []

        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "VulnScan/2.0 Security Scanner",
            **(headers or {}),
        })

    # ── Helpers ────────────────────────────────────────────────

    def _same_domain(self, url: str) -> bool:
        base   = urlparse(self.base_url).netloc
        target = urlparse(url).netloc
        return base == target or target == ""

    def _get(self, url: str):
        try:
            return self.session.get(url, timeout=self.timeout, allow_redirects=True)
        except Exception:
            return None

    def _extract_links(self, soup: BeautifulSoup, page_url: str) -> list:
        links = []
        for tag in soup.find_all("a", href=True):
            full  = urljoin(page_url, tag["href"])
            clean = urlparse(full)._replace(fragment="").geturl()
            if self._same_domain(clean) and clean not in self.visited:
                links.append(clean)
        return links

    def _extract_forms(self, soup: BeautifulSoup, page_url: str) -> list:
        forms = []
        for form in soup.find_all("form"):
            action     = form.get("action", "") or ""
            method     = form.get("method", "get").upper()
            full_action = urljoin(page_url, action) if action else page_url

            inputs, hidden = [], []
            for inp in form.find_all(["input", "textarea", "select"]):
                name   = inp.get("name") or inp.get("id") or ""
                itype  = inp.get("type", "text").lower()
                value  = inp.get("value", "test")

                if not name:
                    continue
                if itype == "hidden":
                    hidden.append({"name": name, "value": value})
                elif itype not in ("submit", "button", "image", "reset"):
                    inputs.append({"name": name, "type": itype, "value": value})

            if inputs:
                forms.append({
                    "action": full_action,
                    "method": method,
                    "inputs": inputs,
                    "hidden": hidden,
                })
        return forms

    # ── Public API ─────────────────────────────────────────────

    def crawl(self) -> tuple:
        """
        BFS crawl up to self.depth levels deep.
        Returns (list_of_urls, list_of_forms).
        """
        queue = deque([(self.base_url, 0)])
        self.visited.add(self.base_url)

        while queue:
            url, level = queue.popleft()
            resp = self._get(url)
            if not resp:
                continue
            ct = resp.headers.get("Content-Type", "")
            if "text/html" not in ct:
                continue

            self.found_urls.append(url)
            soup  = BeautifulSoup(resp.text, "html.parser")
            forms = self._extract_forms(soup, url)
            self.found_forms.extend(forms)

            if level < self.depth:
                for link in self._extract_links(soup, url):
                    if link not in self.visited:
                        self.visited.add(link)
                        queue.append((link, level + 1))

        return self.found_urls, self.found_forms
