"""
cookies.py — Checks Set-Cookie response headers for missing security attributes.
Flags: HttpOnly, Secure, SameSite.
"""

import requests


class CookieScanner:
    def __init__(self, timeout: int = 10, headers: dict = None):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "VulnScan/2.0", **(headers or {})})

    def scan(self, url: str) -> list:
        findings = []
        try:
            resp = self.session.get(url, timeout=self.timeout, allow_redirects=True)

            # Collect raw Set-Cookie strings (may be multiple)
            raw_set_cookie = resp.raw.headers.getlist("Set-Cookie") \
                if hasattr(resp.raw.headers, "getlist") \
                else [resp.headers.get("Set-Cookie", "")]

            for cookie in resp.cookies:
                name = cookie.name

                # Find the raw header line for this cookie
                raw_line = next(
                    (h for h in raw_set_cookie if h.lower().startswith(name.lower() + "=")),
                    ""
                ).lower()

                # ── HttpOnly ──────────────────────────────────────────
                if "httponly" not in raw_line:
                    findings.append({
                        "type":        "Cookie",
                        "severity":    "HIGH",
                        "name":        f"Cookie '{name}' Missing HttpOnly Flag",
                        "url":         url,
                        "param":       f"Set-Cookie: {name}",
                        "payload":     "N/A",
                        "method":      "GET",
                        "evidence":    f"Set-Cookie for '{name}' lacks the HttpOnly attribute",
                        "description": (
                            f"Cookie '{name}' is readable via JavaScript. "
                            "If an XSS vulnerability exists anywhere on the site, "
                            "attackers can steal this cookie and hijack sessions."
                        ),
                        "cvss":        7.4,
                        "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:H/I:N/A:N",
                        "remediation": (
                            f"Append HttpOnly to the cookie directive:\n"
                            f"Set-Cookie: {name}=<value>; HttpOnly; Secure; SameSite=Strict"
                        ),
                        "references":  ["https://owasp.org/www-community/HttpOnly"],
                    })

                # ── Secure ────────────────────────────────────────────
                if "secure" not in raw_line:
                    findings.append({
                        "type":        "Cookie",
                        "severity":    "MEDIUM",
                        "name":        f"Cookie '{name}' Missing Secure Flag",
                        "url":         url,
                        "param":       f"Set-Cookie: {name}",
                        "payload":     "N/A",
                        "method":      "GET",
                        "evidence":    f"Set-Cookie for '{name}' lacks the Secure attribute",
                        "description": (
                            f"Cookie '{name}' can be transmitted over unencrypted HTTP. "
                            "A network attacker (e.g. on public Wi-Fi) can intercept it."
                        ),
                        "cvss":        5.9,
                        "cvss_vector": "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:N/A:N",
                        "remediation": (
                            f"Add the Secure flag:\n"
                            f"Set-Cookie: {name}=<value>; Secure"
                        ),
                        "references":  [],
                    })

                # ── SameSite ──────────────────────────────────────────
                if "samesite" not in raw_line:
                    findings.append({
                        "type":        "Cookie",
                        "severity":    "MEDIUM",
                        "name":        f"Cookie '{name}' Missing SameSite Attribute",
                        "url":         url,
                        "param":       f"Set-Cookie: {name}",
                        "payload":     "N/A",
                        "method":      "GET",
                        "evidence":    f"Set-Cookie for '{name}' lacks the SameSite attribute",
                        "description": (
                            f"Cookie '{name}' has no SameSite restriction. "
                            "It will be sent on cross-origin requests, contributing to CSRF risk."
                        ),
                        "cvss":        5.4,
                        "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:H/A:N",
                        "remediation": (
                            f"Add SameSite=Strict (or Lax for OAuth flows):\n"
                            f"Set-Cookie: {name}=<value>; SameSite=Strict"
                        ),
                        "references":  [
                            "https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Set-Cookie/SameSite"
                        ],
                    })

        except Exception:
            pass

        return findings
