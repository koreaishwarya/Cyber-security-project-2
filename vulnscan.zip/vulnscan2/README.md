# 🛡 VulnScan — Web Application Vulnerability Scanner

A Python/Flask-based web vulnerability scanner covering the OWASP Top 10.
Includes a dark-themed web UI, real-time scan progress, and exportable HTML/JSON reports.

---

## 📁 Project Structure

```
vulnscan/
├── app.py                  # Flask server & scan orchestrator
├── crawler.py              # BFS web crawler (requests + BeautifulSoup)
├── scanner.py              # XSS, SQLi, CSRF, Open Redirect, CMDi, Path Traversal
├── security_headers.py     # HTTP security header checks
├── cookies.py              # Cookie flag checks (HttpOnly, Secure, SameSite)
├── report_generator.py     # HTML & JSON report generation
├── requirements.txt
├── README.md
├── reports/                # Auto-created; stores generated report files
├── templates/
│   ├── index.html          # Main scanner UI
│   └── report.html         # In-browser report viewer
└── static/
    └── css/
        └── style.css       # Full dark-theme stylesheet
```

---

## ⚡ Quick Start

### 1 — Install dependencies

```bash
pip install -r requirements.txt
```

### 2 — Run the server

```bash
python app.py
```

Open **http://localhost:5000** in your browser.

---

## 🔬 Vulnerability Checks

| Check | Severity | Technique |
|---|---|---|
| SQL Injection | CRITICAL | Error-based, payload injection |
| OS Command Injection | CRITICAL | Shell metacharacter injection |
| Reflected XSS | HIGH | Payload reflection detection |
| Path Traversal | HIGH | `../` sequence detection |
| Missing HSTS | HIGH | Header presence check |
| Cookie — HttpOnly | HIGH | Set-Cookie attribute check |
| Open Redirect | MEDIUM | 3xx Location header check |
| CSRF — Missing Token | MEDIUM | Form token field scan |
| Missing CSP / X-Frame-Options | MEDIUM | Header presence check |
| Cookie — Secure / SameSite | MEDIUM | Set-Cookie attribute check |
| Server / X-Powered-By disclosure | INFO | Response header check |

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/scan/start` | Start a new scan |
| `GET`  | `/api/scan/<id>/status` | Poll scan progress & logs |
| `GET`  | `/api/scan/<id>/findings` | Get findings list |
| `GET`  | `/api/scan/<id>/report/json` | Download JSON report |
| `GET`  | `/api/scan/<id>/report/html` | Download HTML report |
| `GET`  | `/api/scans` | List all scans |
| `DELETE` | `/api/scan/<id>` | Delete a scan |

### Start scan — request body

```json
{
  "url":     "https://target.example.com",
  "checks":  ["xss", "sqli", "csrf", "headers", "cookies", "openredirect"],
  "depth":   2,
  "timeout": 10,
  "headers": { "Cookie": "session=abc123" }
}
```

---

## ⚙️ Configuration

All settings are passed per-request in the JSON body (see above).  
For production, swap the in-memory `scans` dict in `app.py` with Redis or SQLite.

---

## ⚠️ Legal Notice

> Use VulnScan **only** on systems you own or have explicit written permission to test.  
> Unauthorized scanning is illegal. The authors accept no liability for misuse.

---

## 🛠 Tech Stack

- **Backend:** Python 3.10+, Flask 3, Requests, BeautifulSoup4
- **Frontend:** Vanilla HTML/CSS/JS (no framework dependencies)
- **Reporting:** Jinja2 (via Flask), self-contained HTML exports
